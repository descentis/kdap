#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr  2 20:57:27 2019

@author: descentis

"""

from kdap.analysis import instances
from kdap.converter.qaConverter import qaConverter
from kdap.analysis import knol
from kdap.wikiextract.wikiExtract import wikiExtract
#from kdap.converter.wikiConverter import wikiConverter
#import xml.etree.ElementTree as ET
#import glob
#import re