#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr  2 20:58:31 2019

@author: descentis
"""

#from kdap.converter.qaConverter import qaConverter